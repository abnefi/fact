class Formulaire {

  /**
   * The main function which call the constructor.
   * This class may not be initialized directly but through this static function
   * @param $selector
   * @param devis
   */
  static bind($selector, devis = false) {
    const invoice = $($selector)
    if (invoice.length > 0) {
      new Formulaire(invoice, devis)
    }
  }

  constructor(invoice, devis) {
    this.entity = 'clientfacturevente'
    if (devis) {
      this.entity = 'clientdevis'
    }

    this.invoice = invoice //Represent the whole invoice
    this.devis = devis
    this.index = 0 //represents the index of articles
    this.saver = this.invoice.find('.btnFormSaver') //The main saver of the form
    this.wrapperTheme = this.invoice.find('.articles_wrapper') //detailForm container. It doesn't contain the 'Ajout à la liste' btn
    this.clientSaver = $('#save_new_client') //The submit btn of the whole form
    this.addBtn = this.invoice.find('#addDetail') //The 'Ajout à la liste" btn that add a new article
    this.data = JSON.parse($('#data_json').val()) //data receive from the server
    this.onLoad = true //To know if it the first time the form is be displayed. Use in the addBtn.on('click')'s function
    this.newForm = '' //Contains the current detail form
    this.unitMesure = '' //the container of the unitMesure input
    this.type = '' //the select used to choose the type of product: article or service
    this.aibInput = '' //the aibInput
    this.taxespec = '' //the specifique taxe input
    this.table = $('#liste-article') //the table that contains the list of article/service added
    this.noProduct = $('#new-facture-no-product') //the ligne that shows 'Aucun produit ajout pour le moment'
    this.totalArticle = 0 //the number of article currently added
    this.pu = '' //the unit price input
    this.typeVal = '' //the val of product; contains either service or article
    this.taxeSejour = '' //contains the taxeSejour input
    this.quantite = '' //the quantity input container
    this.produit = '' //contains the list of product
    this.uttc = '' //contains the unit price ttc input
    this.ttc = '' //contains the ttc price input
    this.description = '' //contains the description textarea
    this.selectCLient = $("#operationsclientbundle_clientfacturevente_client") //the select that contains client list
    if (devis) {
      this.selectCLient = $("#operationsclientbundle_clientdevis_client") //the select that contains client list
    }
    this.tvaInput = this.invoice.find('.tva').find('input') //the tva input
    this.clientIsMoral = false //to know if the client is an entreprise
    this.invoice.find('.devise').find('select').val(this.data.devise) //the put value of the devise

    if (devis) {
      this.totalHTInp = $('#operationsclientbundle_clientdevis_totalHT')
      this.totalTVAInp = $('#operationsclientbundle_clientdevis_totalTVA')
      this.totalAIBInp = $('#operationsclientbundle_clientdevis_totalAIB')
      this.totalTTCInp = $('#operationsclientbundle_clientdevis_totalTTC')
      this.totalTTSInp = $('#totaltaxespecifique')
      this.totalNETInp = $('#totalnet')
    } else {
      this.totalHTInp = $('#operationsclientbundle_clientfacturevente_totalHT')
      this.totalTVAInp = $('#operationsclientbundle_clientfacturevente_totalTVA')
      this.totalAIBInp = $('#operationsclientbundle_clientfacturevente_totalAIB')
      this.totalTTCInp = $('#operationsclientbundle_clientfacturevente_totalTTC')
      this.totalTTSInp = $('#totaltaxespecifique')
      this.totalNETInp = $('#totalnet')
    }

    this.totalHT = 0;
    this.totalHTTemp = 0
    this.totalTVA = 0;
    this.totalTVATemp = 0
    this.totalAIB = 0;
    this.totalAIBTemp = 0
    this.totalTTC = 0;
    this.totalTTCTemp = 0
    this.totalTTS = 0;
    this.totalTTSTemp = 0
    this.totalNET = 0;
    this.totalNETTemp = 0

    console.log(this.data)

    this.addArticle() //bind the click event to the addBtn

    //sets up the submit action on the saveClient btn
    $('#modal_new_client').on('shown.bs.modal', this.activeClientSaver.bind(this))
    this.fillClient() //change the default client list to the customized one I need to work here
    this.saver.on('click', this.submit.bind(this))
  }

  submit(e) {
    e.preventDefault()
    this.newForm.remove()
    if (this.devis) {
      this.invoice.find('form[name="operationsclientbundle_clientdevis"]').submit()
    } else {
      this.invoice.find('form[name="operationsclientbundle_clientfacturevente"]').submit()
    }
  }

  /**
   * Replace the set client list by the customized on the I receive
   * And set up the change event on the client's select
   */
  fillClient() {
    const $this = this;
    $this.selectCLient.html('<option value="" selected="selected">Sélectionnez un client</option>')
    $.each($this.data.clients, function (index, value) {
      $this.selectCLient.append('<option data-ifu="' + value['ifu'] + '" data-moral="' + value['moral'] + '" data-tva="' + value['tva'] + '" value="' + value['id'] + '">' + value['nom'] + '</option>');
    })
    $this.selectCLient.chosen({
      width: "100%",
      placeholder_text_single: "Sélectionner une option"
    });
    $this.selectCLient.trigger("chosen:updated");
    $this.selectCLient.on('change', function () {
      console.log('client change')
      const client = $(this).find('option[value="' + $(this).val() + '"]')

      $this.clientIsMoral = client.data('moral')
      $this.tvaInput.val(client.data('tva'))

      const event = new CustomEvent('clientChange', {
        detail: {
          moral: $this.clientIsMoral,
          ifu: client.data('ifu')
        }
      })
      document.dispatchEvent(event)
      if ($this.pu !== '') {
        $this.calculator()
      }
    })
  }


  /**
   * Manage what happens when the product type change
   */
  selectTypeProduit() {
    this.resetArticleForm()
    this.type.off('change').on('change', this.funcOnTypeArticleChange.bind(this))
  }

  funcOnTypeArticleChange() {
    const $this = this
    $this.typeVal = ''
    const title = $('.article_service')
    if ($this.type.val() === '1') {
      $this.typeVal = 'article'
      title.text('Article')
    } else if ($this.type.val() === '2') {
      $this.typeVal = 'service'
      title.text('Service')
    }

    if ($this.typeVal === 'article') {
      $this.unitMesure.hide()
      $this.quantite.removeClass('col-md-6')
      $this.quantite.addClass('col-md-12')
    }
    if ($this.typeVal === 'service') {
      $this.unitMesure.show()
      $this.quantite.removeClass('col-md-12')
      $this.quantite.addClass('col-md-6')
    }

    $this.produit.html($this.chargeProduit($this.typeVal))

    if (!$this.typeVal) {
      $this.produit.attr('disabled', 1)
      $this.produit.trigger("chosen:updated");
      $this.selecProduit()

    } else {

      $this.produit.chosen({
        width: "100%"
      });
      $this.produit.removeAttr('disabled')
      $this.produit.trigger("chosen:updated");

      $this.produit.off('change').on('change', $this.selecProduit.bind($this))
    }
  }

  /**
   * Manage what happens when we select a product
   */
  selecProduit() {
    const $this = this

    $this.resetArticleForm()
    const $serviceId = $this.produit.val()
    if ($this.typeVal === 'service') {
      $this.unitMesure.find('select').val($this.getInfo('uniteMesure', $serviceId))
    }
    this.taxeSejour.val(0)
    if ($this.getInfo('taxeGroupe', $serviceId) === 'F') {
      this.taxeSejour.closest('.col-md-12').show('slow')
    } else {
      this.taxeSejour.closest('.col-md-12').hide('slow')
    }
    $this.pu.val($this.getInfo('prixUnitaireVente', $serviceId))

    setTimeout(function () {
      $this.quantite.find('input').focus()
    }, 200)
  }

  /**
   * Use to calculate the value of different amount fields each time one of them's value change
   */
  calculator() {
    const qte = this.quantite.find('input').val(),
      //{uttc, taxe, pu, aib, sejour, tvaAppliquee, produit}
      values = this.elmCalculator(this.aibInput, this.taxeSejour, this.taxespec, this.pu, this.produit)

    this.uttc.val(values.uttc)
    this.ttc.val(values.uttc * qte)

    // Calcul en live des totaux. Ceci n'est utile que pour l'animation en live.
    // Sinon le vrai calcul est fait dans totalCalculator() une fois qu'on ajout l'article à la lliste
    this.totalHTTemp = this.totalHT + (values.pu * qte)
    this.totalTTCTemp = this.totalTTC + (values.uttc * qte)
    this.totalAIBTemp = this.totalAIB + (values.aib * qte)
    this.totalTVATemp = this.totalTVA + (values.tvaAppliquee * qte)
    this.totalTTSTemp = this.totalTTS + values.taxe

    this.totalNETTemp = this.netCalculator(this.totalTTCTemp)
    if (this.data.liberal && this.clientIsMoral) {
      this.totalNETTemp = this.netCalculator(this.totalTTCTemp - values.aib)
    }

    this.totalHTInp.val(Math.round(this.totalHTTemp))
    this.totalTVAInp.val(Math.round(this.totalTVATemp))
    this.totalTTSInp.val(Math.round(this.totalTTSTemp))
    this.totalAIBInp.val(Math.round(this.totalAIBTemp))
    this.totalTTCInp.val(Math.round(this.totalTTCTemp))
    this.totalNETInp.val(this.totalNETTemp)
  }

  /**
   * Calculate different like
   *    taxe -> taxe spécifique,
   *    pu -> prix unitaire,
   *    aib -> aib par rapport au pu,
   *    sejour -> la taxe de sejour
   *    uttc -> prix unitaire tout taxe compris,
   *
   * @param aibInput
   * @param taxeSejourInput
   * @param taxeSpecInput
   * @param puInput
   * @param produitInput
   * @param tvaInput
   * @returns {{uttc: (number|*), taxe: number, pu: number, aib: number, sejour: number, tvaAppliquee: number}}
   */
  elmCalculator(aibInput, taxeSejourInput, taxeSpecInput, puInput, produitInput) {
    let
      aib = Number.parseFloat(aibInput.val().replace(',', '.')),
      sejour = taxeSejourInput.val().replace(',', '.'),
      taxe = taxeSpecInput.val().replace(',', '.'),
      pu = puInput.val().replace(',', '.'),
      tva = this.data.assujetiTva ? this.tvaInput.val().replace(',', '.') : 0,
      uttc,
      tvaAppliquee = tva / 100 * pu,
      produit = produitInput.val()
    const groupeTaxe = this.getInfo('taxeGroupe', produit)

    taxe = !taxe ? 0 : taxe * 1
    pu = !pu ? 0 : pu * 1
    aib = !aib ? 0 : aib
    sejour = !sejour ? 0 : sejour * 1

    uttc = pu + taxe + aib + sejour

    if (groupeTaxe !== 'A' && groupeTaxe !== 'E' && this.getInfo('type', produit) !== 'service') {
      uttc += tvaAppliquee
    } else {
      tvaAppliquee = 0
    }
    produit = produitInput.find('option:selected').text()

    return {uttc, taxe, pu, aib, sejour, tvaAppliquee, produit}
  }

  netCalculator(number) {
    if (!this.data.roundPrice || number % 5 === 0) {
      return number
    }
    return number + (5 - (number % 5))
  }

  /**
   * Effective calculator of different total
   */
  totalCalculator() {
    const $this = this
    const tva = this.data.assujetiTva ? this.tvaInput.val() : 0
    let tvaAppliquee = tva / 100 * $this.pu.val()
    const qte = this.quantite.find('input').val()
    const groupeTaxe = this.getInfo('taxeGroupe', this.produit.val())

    if (groupeTaxe === 'A' || groupeTaxe === 'E' || $this.getInfo('type', this.produit.val()) === 'service') {
      tvaAppliquee = 0
    }

    this.totalHT += $this.pu.val() * qte
    this.totalTTC += $this.ttc.val() * 1
    this.totalAIB += $this.aibInput.val() * qte
    this.totalTVA = (this.totalTVA * 1) + (tvaAppliquee * qte)
    this.totalTTS += $this.taxespec.val() * 1
    this.totalNET = (this.totalNET * 1) + ($this.ttc.val() * 1)
    if (this.data.liberal && this.clientIsMoral) {
      this.totalNET = $this.netCalculator($this.totalTTC - $this.totalAIB)
      // this.totalNET = (this.totalNET * 1) + ($this.ttc.val() * 1) - this.totalAIB
    }

    this.totalHTInp.val(this.totalHT)
    this.totalTVAInp.val(this.totalTVA)
    this.totalTTSInp.val(this.totalTTS)
    this.totalAIBInp.val(this.totalAIB)
    this.totalTTCInp.val(this.totalTTC)
    this.totalNETInp.val(/*this.netCalculator(*/this.totalNET/*)*/)
  }

  /**
   * Bind the calculator for different actions that should provoke its work
   */
  onInputchange() {
    const $this = this
    let qte = $this.quantite.find('input')
    qte.off('change').on('change', this.calculator.bind(this))
    qte.off('keyup').on('keyup', this.calculator.bind(this))

    this.aibInput.closest('.form-group')
      .find('input[type="checkbox"]').off('change').on('change', this.calculator.bind(this))

    this.taxespec.off('change').on('change', this.calculator.bind(this))
    this.taxespec.off('keyup').on('keyup', this.calculator.bind(this))
  }

  /**
   * Resets article form in case the type of product is changed for example
   */
  resetArticleForm() {
    this.unitMesure.find('select').val('1')
    this.quantite.find('input').val('')

    this.aibInput.closest('.form-group')
      .find('input[type="checkbox"]')
      .prop('checked', false)
    this.aibInput.val('')

    this.taxespec.closest('.form-group')
      .find('input[type="checkbox"]')
      .prop('checked', false)
    this.taxespec.val('')

    this.ttc.val('')
    this.pu.val('')
    this.uttc.val('')
    this.description.val('')
  }

  /**
   * Receive a kind of information we're looking for
   * (unitPrice for example) and then returns the id of the element in the database
   *
   * @param $info the information we're looking for
   * @param $serviceId the current product selected for which one we're looking for the information
   * @returns {string}
   */
  getInfo($info, $serviceId) {
    let id = ''
    this.data.stock.forEach(function (produit) {
      if (produit.id == $serviceId) {
        id = produit[$info]
        return
      }
    })
    return id
  }

  /**
   * Changes the form title when the product type change
   *
   * @param type
   * @returns {string}
   */
  chargeProduit(type) {
    type = type === '' ? 'élément' : type
    let html = '<option value="">Sélectionnez un ' + type + '</option>'
    this.data.stock.forEach(function (produit) {
      if (produit.type === type) {
        html += `<option value="${produit.id}">${produit.designation}</option>`
      }
    })
    return html;
  }

  /**
   * Binds the click event to the addArticle btn and click once on that btn
   */
  addArticle() {
    const $this = this
    this.addBtn.off('click').on('click', function (e) {
      e.preventDefault()
      if (!$this.onLoad && $this.selectCLient.val() === '' && !$this.data.edit) {
        $this.notif('Veuillez renseigner un client au premier abord', 'warning')
        return
      }
      // TODO: il faut verifier que tous les champs sont bien renseigner avant d'ajouter un autre article
      if ($this.onLoad || ($this.pu.val() !== '' && $this.quantite.find('input').val() !== '')) {
        $('.article_item').hide()
        // Get the data-prototype explained earlier
        let prototypeTheme = $this.wrapperTheme.data('prototype');
        // get the new index
        let index = $this.wrapperTheme.data('index');
        $this.index = index
        console.log('this.index:', $this.index)
        // instead be a number based on how many items we have
        $this.newForm = $(prototypeTheme.replace(/__name__/g, index));
        console.log($this.newForm)
        $this.wrapperTheme.data('index', index + 1);
        $this.wrapperTheme.append($this.newForm);

        if (!$this.onLoad) {
          $this.totalCalculator()
          $this.addArticleToTable()
        }
        $this.onLoad = false

        $this.unitMesure = $this.newForm.find('.unit_mesure')
        $this.quantite = $this.newForm.find('.quantite')
        $this.type = $this.newForm.find('.select_type').find('select')
        $this.taxeSejour = $this.newForm.find('.taxe-de-sejour')
        $this.produit = $this.newForm.find('.select_produit').find('select')
        $this.produit.attr('disabled', '1')
        $this.pu = $this.newForm.find('.prix_vente_unitaire').find('input')
        $this.aibInput = $this.newForm.find('.aib')
        // $this.aibInput.attr('name', 'aib'+index)
        $this.taxespec = $this.newForm.find('.taxespecifique')

        $this.description = $this.newForm.find('.div_description').find('textarea')
        $this.uttc = $this.newForm.find('.prix_unitaire_ttc').find('input')
        $this.ttc = $this.newForm.find('.sousTotalTTC').find('input')

        $this.onInputchange()

        $this.selectTypeProduit()
        const ifu = !!$this.selectCLient.val() ? $this.selectCLient.find('option[value="' + $this.selectCLient.val() + '"]').data('ifu') : ''
        // console.log('article', ifu)
        CheckInput.bind('.checkbox', ifu, $this.data.liberal)

        $(".select_article:last").chosen({
          width: "100%",
          placeholder_text_single: "Sélectionnez une option"
        });
        $(".select_type_produit").chosen({
          width: "100%",
          placeholder_text_single: "Sélectionnez un type"
        });

      } else {
        $this.notif('Veuillez remplir tous les champs et reéssayer', 'warning')
      }
    });

    this.addBtn.click() //add the first article to the page
  }

  /**
   * Add a product to the table once it has be 'added to the list' (Ajouter à la liste)
   */
  addArticleToTable() {
    const $this = this
    $this.totalArticle++
    const tr = $(`
      <tr data-index="${$this.index-1}" style="display: none;">
        <td>${$this.produit.find('option:selected').text()}</td>
        <td>${$this.quantite.find('input').val()}</td>
        <td>${$this.aibInput.val()}</td>
        <td>${Math.round($this.taxespec.val() != '' ? $this.taxespec.val() : 0)}</td>
        <td>${Math.round($this.ttc.val())}</td>
        <td>${$this.description.val().substring(0, 15) + '...'}</td>
        <td>
          <div class="btn-group">
            <button type="button" class="btn btn-info dropdown-toggle" data-toggle="dropdown">
              Action
            </button>
            <ul class="dropdown-menu">
              <li class="edit-article"><a href="#"><i class="fa fa-edit"></i> Editer</a></li>
              <li class="del-article"><a href="#"><i class="fa fa-trash"></i> Supprimer</a></li>
            </ul>
          </div>
        </td>
      </tr>
    `)
    $this.table.append(tr)
    tr.show('slow')

    this.articleActions(false)

    if ($this.totalArticle === 1) {
      $this.noProduct.hide('slow')
    }
  }

  /**
   * Binds action on 'Supprimer' and 'Edit' article on the TABLE's action
   * @param edit
   */
  articleActions(edit) {
    const $this = this
    $('.del-article').off('click').on('click', function (e) {
      $this.deleteArticle(e, this, $this, edit)
    })

    $('.edit-article').off('click').on('click', function (e) {
      $this.editArticle(e, this, $this, edit)
    })
  }

  deleteArticle(e, self, $this, edit) {
    e.preventDefault()
    $this.totalArticle--
    const tr = $(self).closest('tr')

    let
      id = '#operationsclientbundle_' + $this.entity + '_details_'+ tr.data('index') + '_type',
      articleForm = $(id).closest('.article_item')

    if (edit === true) {
      id = '#operationsclientbundle_' + $this.entity + '_details_' + tr.data('index')
      articleForm = $(id).parent('div')
    }

    const qte = articleForm.find('.quantite_produit').val()*1

    tr.hide('slow', function () {
      tr.remove()
      if ($this.totalArticle === 0) {
        $this.noProduct.show('slow')
      }
    })


    //{uttc, taxe, pu, aib, sejour, tvaAppliquee, produit}
    const values = $this.elmCalculator(
      articleForm.find('.aib'),
      articleForm.find('.taxe-de-sejour'),
      articleForm.find('.taxespecifique'),
      articleForm.find('.prix_vente_unitaire'),
      articleForm.find('.select_article')
    )

    $this.totalHT = $this.totalHT - (values.pu * qte)
    $this.totalAIB = $this.totalAIB - (values.aib * qte)
    $this.totalTVA = ($this.totalTVA * 1) - (values.tvaAppliquee * qte)
    $this.totalTTS = $this.totalTTS - values.taxe
    $this.totalTTC = $this.totalTTC - (values.uttc * qte)
    $this.totalNET = $this.netCalculator($this.totalTTC)
    if ($this.data.liberal && $this.clientIsMoral) {
      // TODO: il faut revoir le calcul du total net ici
      $this.totalNET = $this.netCalculator($this.totalTTC - $this.totalAIB)
    }

    $this.totalHTInp.val($this.totalHT)
    $this.totalTVAInp.val($this.totalTVA)
    $this.totalTTSInp.val($this.totalTTS)
    $this.totalAIBInp.val($this.totalAIB)
    $this.totalTTCInp.val($this.totalTTC)
    $this.totalNETInp.val($this.totalNET)

    articleForm.remove()
  }

  editArticle(e, self, $this, edit) {
    e.preventDefault()
    $this.totalArticle--
    const tr = $(self).closest('tr')
    if (!!tr.attr('data-jindex')) {
      $this.deleteArticle(e, self, $this, edit)
    }

    const data = $this.data.edit.details[tr.data('jindex')]
    let id = '#operationsclientbundle_' + $this.entity + '_details_'+ tr.data('index') + '_type'
    if (edit === true) {
      id = '#operationsclientbundle_' + $this.entity + '_details_' + tr.data('index')
    }
    let form = $(id).closest('.article_item')
    if (edit === true) {
      form = $(id).parent('div')
    }

    if (!!tr.attr('data-jindex')) {
      $this.selectTypeProduit()

      $this.newForm.find('.select_type_produit').find('option').each(function () {
        const option = $(this)
        if (option.text().trim().toLowerCase() === $this.getInfo('type', data.produit)) {
          option.attr('selected', 'selected')
        }
      })
      $this.funcOnTypeArticleChange()
      $this.newForm.find('.select_article').val(data.produit)
      $this.newForm.find('.description').val(data.description)
      $this.newForm.find('.unite_mesure').val(data.uniteMesure)
      $this.newForm.find('.quantite_produit').val(data.quantite)
      $this.newForm.find('.taxe-de-sejour').val(data.taxeDeSejour)
      $this.newForm.find('.prix_vente_unitaire').val(data.prixVenteUnitaire)
      if (data.hasTaxeSpecifique) {
        $this.newForm.find('.checkbox_taxe_specifique').prop('checked', true)
        $this.newForm.find('.taxespecifique').val(data.taxeSpecifique)
        $this.newForm.find('.taxespecifique').removeAttr('disabled')
        $this.newForm.find('.textarea_description_taxe_specifique').val(data.description)
        $this.newForm.find('.textarea_description_taxe_specifique').show('slow')
      }

      let aib = 0
      if (data.aibDeductible) {
        aib = data.tauxAIB * data.prixVenteUnitaire
        $this.newForm.find('.aib').val(aib)
        $this.newForm.find('.aib').parent('div').find('input[type="checkbox"]').prop('checked', true)
      }

      const puTTC = data.prixVenteUnitaire + data.taxeSpecifique + data.taxeDeSejour
      $this.newForm.find('.prix_unitaire_ttc').find('input').val(puTTC)
      $this.newForm.find('.sousTotalTTC').find('input').val(puTTC * data.quantite)

      $this.newForm.find('.chosen-select').trigger("chosen:updated");

      form.remove()

    } else {
      $this.newForm.remove()
      form.show()

      $this.quantite = form.find('.quantite')
      $this.pu = form.find('.prix_vente_unitaire').find('input')

      //$this.newForm = $(prototypeTheme.replace(/__name__/g, index));
      $this.unitMesure = form.find('.unit_mesure')
      $this.type = form.find('.select_type').find('select')
      $this.taxeSejour = form.find('.taxe-de-sejour')
      $this.produit = form.find('.select_produit').find('select')
      $this.aibInput = form.find('.aib')
      $this.taxespec = form.find('.taxespecifique')

      $this.description = form.find('.div_description').find('textarea')
      $this.uttc = form.find('.prix_unitaire_ttc').find('input')
      $this.ttc = form.find('.sousTotalTTC').find('input')

      $this.index = tr.data('index')+1
    }

    tr.hide('slow', function () {
      tr.remove()
      if ($this.totalArticle === 0) {
        $this.noProduct.show('slow')
      }
    })

    if ($this.totalArticle === 1) {
      $this.noProduct.hide('slow')
    }
  }

  /**
   * The notification tooltips shower
   *
   * @param message
   * @param type
   */
  notif(message, type) {
    if (!type) type = 'success'
    var element = $('#alert-raw')
    element.fadeOut(1)
    element.removeClass('alert-danger')
    element.removeClass('alert-success')
    element.removeClass('alert-warning')
    element.addClass('alert-' + type)
    element.find('p').text(message)
    element.fadeIn(500)
    element.find('.user-close-message-box').on('click', function () {
      element.fadeOut(2000)
    })
    setTimeout(function () {
      element.fadeOut(2000)
    }, 10000)
  }

  /**
   * Binds the click action to the clientSaver
   */
  activeClientSaver() {
    this.clientSaver.off('click').on('click', this.saveClient.bind(this))
  }

  /**
   * Saves the client
   * Add the new client to the select list
   * And select the client
   *
   * @param e
   * @returns {number}
   */
  saveClient(e) {
    e.preventDefault();
    const $this = this
    const btn = $this.clientSaver
    btn.button('loading')

    //gestion de validations des champs
    let finish = false;
    $(".req").each(function () {
      if ($(this).val() === '') {
        $("#ctl_al").show();
        finish = true;
      }
    });
    if (finish) {
      return 0;
    }

    let form = $('#formNewClient')

    $.ajax({
      type: "POST",
      url: form.attr('action'),
      processData: false,
      contentType: false,
      data: new FormData(form[0]),
      success: function (response) {
        if (response.error !== undefined) {
          $('#modal_new_client').find('.modal-content').html(response.body)
          $("#save_new_client").off('click').on('click', $this.saveClient.bind($this))
        } else {
          $.each(response['arrayClients'], function (index, value) {
            // console.log(value['designation']);
            $this.selectCLient.append('<option data-ifu="' + value['ifu'] + '" data-moral="' + value['moral'] + '" data-tva="' + value['tva'] + '" selected value="' + value['id'] + '">' + value['nom'] + '</option>');
          })
          $this.selectCLient.chosen({
            width: "100%",
            placeholder_text_single: "Sélectionner une option"
          });
          $this.selectCLient.val(response['idNewClient']);
          $this.selectCLient.trigger("chosen:updated");
          // TODO: chargé l'aib et le tva du client
          //ajaxFacture.getAibByClient($this.selectCLient.val(), $("#operationsclientbundle_clientfacturevente_tauxAIB"));
          $('#form_shortcut_new_client').empty();
          $('#newClient').hide();
          $('#modal_new_client').modal('hide');
        }
      },
      always: function () {
        btn.button('reset')
      }
    })
  }

}


class FormulaireEdit extends Formulaire {

  /**
   * The main function which call the constructor.
   * This class may not be initialized directly but through this static function
   * @param $selector
   * @param devis
   */
  static bind($selector, devis = false) {
    const invoice = $($selector)
    if (invoice.length > 0) {
      new FormulaireEdit(invoice, devis)
    }
  }

  constructor(invoice, devis) {
    super(invoice, devis)

    this.oldArticle = $('#operationsclientbundle_'+this.entity+'_details')

    this.edit = this.data.edit
    this.dateFacture = $('.date-facture').find('input')
    this.dateReglement = $('.date-reglement').find('input')

    if (!!this.edit) {
      this.fillFacture()
      console.log('edit')
      this.preFillArticleToTable()
    }
  }

  /**
   * To fill information about the facture
   */
  fillFacture() {
    const inputGroup = this.selectCLient.closest('.input-group')
    const parent = inputGroup.parent()
    inputGroup.hide()

    parent.append(
      `<div class="input-group"><input type="text" class="form-control" readonly="readonly" value="${this.edit.client}"></div>`
    )

    let dateFacture = this.edit.data_facture.date
    let dateReglement = (new Date()).getFullYear() + '-' + (new Date()).getMonth() + '-' + (new Date()).getDay() + ' 00:00:00'
    if(!!this.edit.data_reglement) {
      dateReglement = this.edit.data_reglement.date
    }
    dateFacture = dateFacture.split(' ');
    dateReglement = dateReglement.split(' ');
    this.dateFacture.val(dateFacture[0])
    this.dateReglement.val(dateReglement[0])
    console.log(dateFacture[0],
    dateReglement[0])
    this.invoice.find('.devise').find('select').val(this.edit.devise)

    this.tvaInput.val(this.edit.tva)

    //loading sum variables and inputs
    this.totalHT = this.edit.totalHT
    this.totalAIB = this.edit.totalAIB
    this.totalTTC = this.edit.totalTTC
    this.totalTVA = this.edit.totalTVA
    this.totalTTS = this.ttsCalculator()
    this.totalNET = this.netCalculator(this.totalTTCInp.val()*1)

    this.totalHTInp.val(this.totalHT)
    this.totalTVAInp.val(this.totalTVA)
    this.totalTTSInp.val(this.totalTTS)
    this.totalAIBInp.val(this.totalAIB)
    this.totalTTCInp.val(this.totalTTC)
    this.totalNETInp.val(this.totalNET)
  }


  ttsCalculator() {
    let tts = 0
    this.edit.details.forEach(function (article) {
      tts += article.taxeSpecifique*1
    })
    return tts
  }


  /**
   * Add a product to the table once it has be 'added to the list' (Ajouter à la liste)
   */
  preFillArticleToTable() {
    const $this = this
    let loop = 0
    this.oldArticle.children().each(function () {
      const detail = $(this),
        index = $this.totalArticle,
        preID = '#operationsclientbundle_'+$this.entity+'_details_' + index + '_',
        qte = detail.find(preID+'quantite').val()
      $this.totalArticle++

      //Needs to be calcule here because this aibInput doesn't contain the aib value but the tauxAib
      let aibValue = Number.parseFloat(detail.find(preID+'tauxAIB').val().replace(',', '.'))
      aibValue *= detail.find(preID+'prixVenteUnitaire').val()
      detail.find(preID+'tauxAIB').val(aibValue)

      //{uttc, taxe, pu, aib, sejour, tvaAppliquee, produit}
      const values = $this.elmCalculator(
        detail.find(preID+'tauxAIB'),
        detail.find(preID+'taxeDeSejour'),
        detail.find(preID+'taxeSpecifique'),
        detail.find(preID+'prixVenteUnitaire'),
        detail.find(preID+'produit')
      )

      const tr = $(`
        <tr data-jindex="${loop}" data-index="${index}" style="display: none;">
          <td>${values.produit}</td>
          <td>${qte}</td>
          <td>${values.aib}</td>
          <td>${Math.round(values.taxe)}</td>
          <td>${Math.round(values.uttc * qte)}</td>
          <td>${detail.find(preID+'description').text().substring(0, 15) + '...'}</td>
          <td>
            <div class="btn-group">
              <button type="button" class="btn btn-info dropdown-toggle" data-toggle="dropdown">
                Action
              </button>
              <ul class="dropdown-menu">
                <li class="edit-article"><a href="#"><i class="fa fa-edit"></i> Editer</a></li>
                <li class="del-article"><a href="#"><i class="fa fa-trash"></i> Supprimer</a></li>
              </ul>
            </div>
          </td>
        </tr>
      `)
      loop++
      $this.table.append(tr)
      tr.show('slow')

      $this.articleActions(true)

      if ($this.totalArticle === 1) {
        $this.noProduct.hide('slow')
      }
    })
  }

}