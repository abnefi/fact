class CheckInput {

  constructor(elm, ifu, liberal) {
    this.elm = $(elm).closest('.form-group')
    $(elm).removeClass('checkbox')
    this.inp = this.elm.find('input[type="text"]')
    this.liberal = liberal
    this.checker = this.elm.find('input[type="checkbox"]')
    this.inp.attr('disabled', 1)
    this.inp.attr('placeholder', '')
    console.log('check', ifu)
    this.tauxAIB = ifu === '' ? this.aib5percent() : 0.01
    this.label = this.inp.closest('.form-group').find('label')
    this.labelText = this.label.text().trim()
    this.motif = this.inp.closest('.row').find('.raisonTaxeSpec')
    this.active()
    this.aibPercentage()
  }

  active() {
    const $this = this
    this.checker.on('click', function () {
      if ($this.inp.hasClass('aib')) {
        $this.label.text($this.labelText + ' (' + $this.tauxAIB*100 + '%)')
      }

      if($(this).is(':checked')) {
        $this.inp.removeAttr('disabled')
        if ($this.inp.hasClass('aib')) {
          $this.inp.attr('readonly', 1)
          $this.aibCalculator()
        } else {
          $this.inp.attr('placeholder', 'Entrez une valeur')
          $this.inp.focus()
        }
        if ($this.inp.hasClass('taxespecifique')) {
          $this.motif.show('slow')
        }
      } else {
        $this.inp.attr('placeholder', '')
        $this.inp.attr('disabled', 1)
        $this.inp.val('')
        if ($this.inp.hasClass('taxespecifique')) {
          $this.motif.hide('slow')
        }
      }
    })
  }

  aibPercentage() {
    const $this = this
    $(document).on('clientChange', function (data) {
      if ($this.inp.hasClass('aib')) {
        data = data.detail
        //{moral: false, liberal: false, ifu: 1234569877896}
        const _5percent = $this.aib5percent()
        $this.tauxAIB = data.ifu != '' ? 0.01 : _5percent

        if ($this.inp.hasClass('aib')) {
          $this.label.text($this.labelText + ' (' + $this.tauxAIB*100 + '%)')
        }
        if ($this.inp.val() !== '') {
          $this.aibCalculator()
        }
      }
    })
  }

  aib5percent() {
    let _5percent = 0.05
    if (this.liberal) {
      _5percent = 0.03
    }
    return _5percent
  }

  aibCalculator() {
    let pu = this.inp.closest('.article_item').find('.prix_vente_unitaire').find('input').val()
    if (!pu) {
      pu = 0
    }
    pu *= 1
    const aib = pu * this.tauxAIB
    this.inp.val(aib)
  }

  static bind($selector, ifu, liberal) {
    const input = $($selector)
    if (input.length > 0) {
      input.each(function () {
        new CheckInput($(this), ifu, liberal)
      })
    }
  }


}
