function constructor(invoice, devis) {
  this.invoice = invoice //Represent the whole invoice
  this.devis = devis
  this.saver = this.invoice.find('.btnFormSaver') //The main saver of the form
  this.wrapperTheme = this.invoice.find('.articles_wrapper') //detailForm container. It doesn't contain the 'Ajout à la liste' btn
  this.clientSaver = $('#save_new_client') //The submit btn of the whole form
  this.addBtn = this.invoice.find('#addDetail') //The 'Ajout à la liste" btn that add a new article
  this.data = JSON.parse($('#data_json').val()) //data receive from the server
  this.onLoad = true //To know if it the first time the form is be displayed. Use in the addBtn.on('click')'s function
  this.newForm = '' //Contains the current detail form
  this.unitMesure = '' //the container of the unitMesure input
  this.type = '' //the select used to choose the type of product: article or service
  this.aibInput = '' //the aibInput
  this.taxespec = '' //the specifique taxe input
  this.table = $('#liste-article') //the table that contains the list of article/service added
  this.noProduct = $('#new-facture-no-product') //the ligne that shows 'Aucun produit ajout pour le moment'
  this.totalArticle = 0 //the number of article currently added
  this.pu = '' //the unit price input
  this.typeVal = '' //the val of product; contains either service or article
  this.taxeSejour = '' //contains the taxeSejour input
  this.quantite = '' //the quantity input container
  this.produit = '' //contains the list of product
  this.uttc = '' //contains the unit price ttc input
  this.ttc = '' //contains the ttc price input
  this.description = '' //contains the description textarea
  this.selectCLient = $("#operationsclientbundle_clientfacturevente_client") //the select that contains client list
  if (devis) {
    this.selectCLient = $("#operationsclientbundle_clientdevis_client") //the select that contains client list
  }
  this.tvaInput = this.invoice.find('.tva').find('input') //the tva input
  this.clientIsMoral = false //to know if the client is an entreprise
  this.invoice.find('.devise').find('select').val(this.data.devise) //the put value of the devise

  if (devis) {
    this.totalHTInp = $('#operationsclientbundle_clientdevis_totalHT')
    this.totalTVAInp = $('#operationsclientbundle_clientdevis_totalTVA')
    this.totalAIBInp = $('#operationsclientbundle_clientdevis_totalAIB')
    this.totalTTCInp = $('#operationsclientbundle_clientdevis_totalTTC')
    this.totalTTSInp = $('#totaltaxespecifique')
    this.totalNETInp = $('#totalnet')
  }else{
    this.totalHTInp = $('#operationsclientbundle_clientfacturevente_totalHT')
    this.totalTVAInp = $('#operationsclientbundle_clientfacturevente_totalTVA')
    this.totalAIBInp = $('#operationsclientbundle_clientfacturevente_totalAIB')
    this.totalTTCInp = $('#operationsclientbundle_clientfacturevente_totalTTC')
    this.totalTTSInp = $('#totaltaxespecifique')
    this.totalNETInp = $('#totalnet')
  }

  this.totalHT = 0; this.totalHTTemp = 0
  this.totalTVA = 0; this.totalTVATemp = 0
  this.totalAIB = 0; this.totalAIBTemp = 0
  this.totalTTC = 0; this.totalTTCTemp = 0
  this.totalTTS = 0; this.totalTTSTemp = 0
  this.totalNET = 0; this.totalNETTemp = 0

  console.log(this.data)

  this.addArticle() //bind the click event to the addBtn

  //sets up the submit action on the saveClient btn
  $('#modal_new_client').on('shown.bs.modal', this.activeClientSaver.bind(this))
  this.fillClient() //change the default client list to the customized one I need to work here
  this.saver.on('click', this.submit.bind(this))
}