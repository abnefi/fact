class FormulaireAvoir extends Formulaire{

  /**
   * The main function which call the constructor.
   * This class may not be initialized directly but through this static function
   * @param $selector
   */
  static bind($selector) {
    const invoice = $($selector)
    if (invoice.length > 0) {
      new FormulaireAvoir(invoice)
    }
  }

  constructor(invoice) {
    super(invoice)
  }

}